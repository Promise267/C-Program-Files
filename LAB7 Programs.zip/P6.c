#include<stdio.h>
#include<string.h>
struct library
{
	int id;
	char title[30];
	char author[30];
	int price;
}l[1000];
int main()
{
	char x[30],aut[30] ;
	int n,c,i,j,id;
	
	printf("Enter number of books:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("\nBook ID:");
		scanf("%d",&l[i].id);
		
		printf("Title of book:");
		gets(l[i].title);
		scanf("%[^\n]s",&l[i].title);
		
		printf("Author of book:");
		gets(l[i].author);
		scanf("%[^\n]s",l[i].author);
		
		printf("Price:");
		scanf("%d",&l[i].price);
		
	}
	
	printf("1)Add book information ");
	printf("\n2)Display book information in ascending order by book name ");
	printf("\n3)List all books of given author ");
	printf("\n4)List the counts of the books in the library ");
	printf("\n5)List the information about the book whose id is given by user ");
	printf("\n6)Exit");
	
	printf("\nChoose one of the above:");
	scanf("%d",&c);
	
	switch(c)
	{
		case 1:
					printf("\nBook ID:");
					scanf("%d",&l[n].id);
	
					printf("Title of book:");
					scanf("%[^\n]s",&l[n].title);
	
					printf("Author of book:");
					gets(l[i].author);
					scanf("%[^\n]s",l[n].author);
	
					printf("Price:");
					scanf("%d",&l[n].price);
					
					printf("\nThe book has been added");
					
					break;

		case 2:
					for(i=0;i<n-1;i++)
					{
						for(j=i+1;j<n;j++)
						{
							if(strcmp(l[i].title,l[j].title)>0)
							{
								strcpy(x,l[j].title);
								strcpy(l[j].title,l[i].title);
								strcpy(l[i].title,x);
							}
						}
					}
					
					for(i=0;i<n;i++)	
						printf("%d\t%s\t%s\t%d\n",l[i].id,l[i].title,l[i].author,l[i].price);	
		
					break;
		
		case 3:
				
					printf("Enter author name:");
					gets(aut);
					scanf("[^\n]s",aut);
					
					for(i=0;i<n;i++)
					{
						if(strcmp(aut,l[i].author)==0)
							{
								printf("%d\t%s\t%s\t%d\n",l[i].id,l[i].title,l[i].author,l[i].price);
							}	
					}
					break;
		case 4:
					printf("No. of books = %d",n);
					break;
		case 5:
					printf("Enter Book ID:");
					scanf("%d",&id);
					
					for(i=0;i<n;i++)
						{
							if(l[i].id==id)
									printf("%d\t%s\t%s\t%d\n",l[i].id,l[i].title,l[i].author,l[i].price);
						}
					break;
		case 6:
					return 0;
								
		default:
					printf("Wrong choice");				
					
	
	}	
	return 0;
}
