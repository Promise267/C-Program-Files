#include<stdio.h>
void display(int);
struct bank
{
	int ac;
	int name[30];
	int balance;
}a[250];

int main()
{
	int n,i,x,an,wd,b;
	
	printf("No. of customers(not more than 250):");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("\nAccount No. :");
		scanf("%d",&a[i].ac);
		
		printf("Name:");
		gets(a[i].name);
		scanf("%[^\n]s",a[i].name);
		
		printf("Balance:");
		scanf("%d",&a[i].balance);
	}
	
	display(n);
		
	printf("\nPress 1 for deposit and 0 for withdrawal:");
	scanf("%d",&x);	
	
	if(x==1)
	{
		printf("\nAccount No.");
		scanf("%d",&an);
		
		for(i=0;i<n;i++)
		{
			if(an==a[i].ac)
			{
			printf("Balance:");
			scanf("%d",&b);
			
			printf("%d is deposited to account number %d",b,an);
			break;
			
			}
		}
		
		if(i==n)
			printf("Account Number not found");			
	}
	
	else if(x==0)
	{
		printf("\nAccount No.");
		scanf("%d",&an);
		
		for(i=0;i<n;i++)
		{
			if(an==a[i].ac)
			{
				
			printf("Balance:");
			scanf("%d",&b);
			
			if(b<=a[i].balance)
				printf("%d is deposited to account number %d",b,an);
			else 
				printf("Not enough balance");
				
			break;
			
			}
		}
		
		if(i==n)
			printf("Account Number not found");	

	}
	
	else
		printf("Wrong choice");
	
	return 0;
	
}

void display(int n)
{
	int i;
	
	printf("\nAccounts with balance below 1000:\n");
	for(i=0;i<n;i++)
	{
		if(a[i].balance<1000)
			printf("%d\t%s\t\t%d\n",a[i].ac,a[i].name,a[i].balance);
	}
	
}
