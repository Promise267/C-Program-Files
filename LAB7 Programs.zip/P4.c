#include<stdio.h>
struct cricket
{
	char name[30];
	int age;
	int no;
	int avg;
}t,c[10];
int main()
{
	
	int i,j;
	
	for(i=0;i<10;i++)
	{
		printf("\nAge:");
		scanf("%d",&c[i].age);
		
		printf("Name:");
		gets(c[i].name);
		scanf("%[^\n]s",c[i].name);
		

		
		printf("No. of test match:");
		scanf("%d",&c[i].no);
		
		printf("Average Runs:");
		scanf("%d",&c[i].avg);
	}
	
	for(i=0;i<9;i++)
	{
		for(j=i+1;j<10;j++)
		{
			if(c[i].avg>c[j].avg)
			{
				t=c[j];
				c[j]=c[i];
				c[i]=t;
			}
		}
	}
	
	printf("\nName\tAge\tNo.of match\tAverage Run\n");
	for(i=0;i<10;i++)
		printf("%s\t%d\t%d\t\t%d\n",c[i].name,c[i].age,c[i].no,c[i].avg);
	
}
