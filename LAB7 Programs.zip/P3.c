#include<stdio.h>
#include<stdlib.h>
typedef struct parts
{
	char sn[4];
	char material[20];
	int quantity, year;
}parts;

void main()
{
	parts car[3];
	int i, n;
	printf("ENTER NUMBER OF PARTS : ");
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		printf("\nENTER THE FOLLOWING INFORMATIONS  : \n");
		printf("SERIAL NO : ");
		fflush(stdin);
		gets(car[i].sn);
		printf("MANUFACTURE DATE : ");
		scanf("%d", &car[i].year);
		printf("QUANTITY : ");
		scanf("%d", &car[i].quantity);
		fflush(stdin);
		printf("MANUFACTURE MATERIAL : ");
		gets(car[i].material);
		fflush(stdin);
	}
	for(i=0; i<n; i++)
	{
		int i;
		if((car[i].sn[0] == 'B' && car[i].sn[2]>='1')||(car[i].sn[0] == 'C' && car[i].sn[2]>'6'))
		{
			printf("CARS BETWEEN BB2 AND CC6 ARE : \n");
			printf("SERIAL NO : %s", car[i].sn);
			printf("\nMANUFACTURE DATE : %d", car[i].year);
			printf("\nQUANTITY: %d", car[i].quantity);
			printf("\nMANUFACTURE MATERIAL : %s", car[i].material);
		}
	}
}
