#include<stdio.h>
void year(int,int);
void roll(int,int);
struct student
{
	int roll;
	char name[30];
	char depart[10];
	char course[10];
	int year;
}s[450];
int main()
{
	int i,n,y,r;
	printf("No. of students(not more than 450):");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter name of student:");
		gets(s[i].name);
		scanf("%[^\n]s",s[i].name);			
		printf("Roll No. :");
		scanf("%d",&s[i].roll);	
		printf("Department:");
		gets(s[i].depart);
		scanf("%[^\n]s",s[i].depart);
		printf("Course:");
		gets(s[i].course);
		scanf("%[^\n]s",s[i].course);
		printf("Year of Joining:");
		scanf("%d\n",&s[i].year);
	}
	printf("\nEnter a year to see the data:");
	scanf("%d",&y);
	year(y,n);
	printf("\nEnter roll number to see data:");
	scanf("%d",&r);
	roll(r,n);
	return 0;
}
void year(int x, int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		if(x==s[i].year)
			printf("%10s%10d%10s%10s%10d\n",s[i].name,s[i].roll,s[i].depart,s[i].course,s[i].year);
	}	
}
void roll(int x, int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		if(x==s[i].roll)
			printf("%s\t%d\t%s\t%s\t%d",s[i].name,s[i].roll,s[i].depart,s[i].course,s[i].year);
	}	
}
