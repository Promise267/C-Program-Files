#include<stdio.h>
#include<string.h>
struct student
{
	int sid;
	int sub1;
	int sub2;
	int sub3;
	int sub4;
	int sub5;
	int total;
	char name;
}t, s[1000];
int main()
{
	int i,j,n,id;
	printf("No. of students:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("\nStudent ID number:");
		scanf("%d",&s[i].sid);
		
		printf("Name of Student : ");
		gets(s[i].name);
		scanf("%[^\n]s",&s[i].name);
		
		printf("Marks in sub1:");
		scanf("%d",&s[i].sub1);
		
		printf("Marks in sub2:");
		scanf("%d",&s[i].sub2);
		
		printf("Marks in sub3:");
		scanf("%d",&s[i].sub3);
		
		printf("Marks in sub4:");
		scanf("%d",&s[i].sub4);
		
		printf("Marks in sub5:");
		scanf("%d",&s[i].sub5);
		
		s[i].total=s[i].sub1+s[i].sub2+s[i].sub3+s[i].sub4+s[i].sub5;
	}	
	
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(s[i].total>s[j].total)
			{
				t=s[j];
				s[j]=s[i];
				s[i]=t;
			}
		}
	}
	
	printf("ID\tName\tsub1\tsub2\tsub3\tsub4\tsub5\tTotal\n");

	for(i=0;i<n;i++)
	{
				printf("%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\n",s[i].sid, s[i].name, s[i].sub1, s[i].sub2, s[i].sub3, s[i].sub4, s[i].sub5, s[i].total);

		}	
		
	printf("\nHighest marks scorer:\n"); 
	
		printf("ID\tName\tsub1\tsub2\tsub3\tsub4\tsub5\tTotal\n");
		printf("%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\n",s[n-1].sid, s[n-1].name, s[n-1].sub1, s[n-1].sub2, s[n-1].sub3, s[n-1].sub4, s[n-1].sub5, s[n-1].total);
		
	printf("\nEnter student ID:");
	scanf("%d",&id);
	
	for(i=0;i<n;i++)
	{
		if(id==s[i].sid)
		{
			printf("ID\tName\tsub1\tsub2\tsub3\tsub4\tsub5\tTotal\n");
			printf("%d\t%s\t%d\t%d\t%d\t%d\t%d\t%d\n", s[i].sid, s[i].name, s[i].sub1, s[i].sub2, s[i].sub3, s[i].sub4, s[i].sub5, s[i].total);
			break;		
		}
	}
	if(i==n)
		printf("ID not found");	
	return 0;
}
