#include<stdio.h>
void main()
{
	int n,count=0;
	printf("enter a number : ");
	scanf("%d",&n);
	do
	{
		if( n % 2 == 0 )
		{
			n/=2;
			printf("Initial Value is %d\n",n);
		}
		else
		{
			n = 3 * n + 1;
			printf("Initial Value is %d\n",n);
		}
		count = count + 1;
	}
	while(n>1);
	printf("the number of steps %d", count);
}
