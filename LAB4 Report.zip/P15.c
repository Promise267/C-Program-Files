#include<stdio.h>
#include<math.h>
void main()
{
	int num,z;
	num = 1;
	while( num <= 1000 )
	{
		printf("%d\t",num);
		num = pow(num,2) + 1;
		z=num;
	}
}
