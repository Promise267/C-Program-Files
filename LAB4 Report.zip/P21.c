#include <stdio.h>
void main()
{
	char ch;
	int i,n=0,p=0,z=0;
	do
	{
		printf("Enter an integer: \n");
		scanf("%d",&i);
		if(i>0)
			p++;
		else if(i<0)
			n++;
		else
			z++;
		printf("Do you want to continue? y/n \n");
		scanf(" %c",&ch);
	}
	while(ch=='y' || ch=='Y');
	printf("Count of +ve , -ve and zeroes entered are %d , %d and %d respectively.",p,n,z);
}
