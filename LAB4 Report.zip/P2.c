#include<stdio.h>
void main()
{
	int num,i,sum=0;
	printf("enter a number to display sum of digits from 1 to 100 exactly divisible by the given number : ");
	scanf("%d", &num);
	{
		for(i=1;i<=100;i++)
		{
			if(i%num==0)
			{
				sum+=i;
			}		
		}
	printf("the sum of numbers from 1 to 100 exactly divisible by %d = %d", num, sum);
	}
}
