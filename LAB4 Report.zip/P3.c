#include<stdio.h>
void main() 
{
	float out=0;
	for(float i=1;i<=99;i++)
	{
    out=out+i/(i+1);
	}
	cout<<out;
}
print(sum([i/(i+1) for i in range(1,100)]))
