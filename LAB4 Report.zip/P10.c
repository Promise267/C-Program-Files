#include<stdio.h>
#include<conio.h>
int main()
{
    char ascii;
    int i;
    i=0;
    while(i<=255)    
	{
    	printf("%c = %d\n", i, i);
    	i++;
    }
}
