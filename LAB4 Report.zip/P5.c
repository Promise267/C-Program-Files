#include <stdio.h>
void main()
{
	int i, num1, num2;
	double pnum = 1;
	printf("Enter an integer :");
	scanf("%d",&num1);
	printf("Enter the value of power which is to be raised to the number :");
	scanf("%d",&num2);
	if (num2 > 0)
	{
		for (i = num2; i>0; i--)
		pnum = pnum * num1;
	}
	else if(num2 < 0)
	{
		for(i=num2; i<0; i++)
		pnum = pnum/num1;
	}
	printf("%d Raised to the Power of %d = %.2f", num1, num2, pnum);
}
