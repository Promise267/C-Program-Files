#include<stdio.h>
#include<math.h>
void main()
{
	int num,rem,realnum,z=0;
	printf("CHECK WETHER THE NUMBER IS ARMSTRONG OR NOT\n");
	printf("----------------------------------------------\n");
	printf("enter a number : ");
	scanf("%d", &num);
	realnum=num;
	while(realnum!=0)
	{
		rem = realnum%10;
		z = z + pow(rem,3);
		realnum/=10;
	}
	if(z == num)
		printf("%d is armstrong", z);
	else
		printf("%d is not armstrong", z);
}
