#include<stdio.h>
void main()
{
    int i,j,num;
    printf("Enter the number : ");
    scanf("%d",&num);
    for(i=0;i<=num;i++)
    {
        for(j=0;j<=num;j++)
        {
            printf("%c",219);
            printf(" ");
        }
        printf("\n");
        if(i%2==0)
        {
            printf("%c",255);
        }
    }
} 
