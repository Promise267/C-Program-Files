#include<stdio.h>
#include<math.h>  
int main()  
{  
    int num, count = 1, rem, sum;  
	do
    {  
        num = count;  
        sum = 0;  
        while(num)  
        {  
            rem = num % 10;  
            sum = sum + pow(rem,3);  
            num = num / 10;  
        }  
        if(count == sum)  
        {  
            printf("%d\n", count);  
        }  
        count++;  
    }  
    while(count <= 1000);  
} 
