#include<stdio.h>
void main()
{
  int num,temp,factor=1;
  printf("Enter a multidigit number: ");
  scanf("%d",&num);
  temp=num;
  while(temp)
  {
    temp=temp/10;
    factor = factor*10;
  }
  printf("Each digits of given number are: ");
  while(factor>1)
  {
    factor = factor/10;
    printf("%d\t",num/factor);
    num = num % factor;
  }
}
