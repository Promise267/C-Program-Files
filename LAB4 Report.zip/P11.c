#include<stdio.h>
int main()
{
	int num,rem,rev=0,z;
	printf("CHECK WETHER THE NUMBER IS PALINDROME OR NOT\n");
	printf("----------------------------------------------\n");
	printf("enter a number : ");
	scanf("%d", &num);
	z=num;
	while(num!=0)
	{
		rem = num%10;
		rev=rev*10+rem;
		num=num/10;
	}
	if(z == rev)
		printf("%d is palindrome", z);
	else
		printf("%d is not palindrome", z);
}
