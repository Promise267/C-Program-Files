#include<stdio.h>  
void main()  
{ 
    int num, b = 0, r = 0, p = 1;  
    printf("Enter a decimal number : ");  
    scanf("%d", &num);  
    printf("Binary equivalent of %d = ", num);  
    while(num)  
    { 
        r   = num % 2;  
        num   = num / 2;  
        b   = b + (r * p);  
        p = p * 10;  
    }  
    printf("%d\n", b);    
}  
