#include<stdio.h>
#include<math.h>
void main()
{
	int num,sum=0;
	num = 1;
	while( num <= 15 )
	{
        sum = sum + pow((2 * num - 1),2);
		num = num + 2;
	}
	printf("the sum of the series is : %d", sum);
}
