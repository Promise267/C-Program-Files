#include<stdio.h>
#include<conio.h>
int main()
{
	int arr[100], i, j, n, large;
	printf("				PROGRAM TO DISPLAY GREATEST NUMBER AMONG ELEMENTS OF ARRAY\n");
	printf("					(NOTE : ARRAY SIZE MUST NOT EXCEED 100)\n");
	printf("-----------------------------------------------------------------------------------------------------------------------\n");
	printf("ENTER ARRAY SIZE : \n");
	scanf("%d", &n);
	printf("ENTER %d ARRAY ELEMENTS : \n", n);
	for(i=0; i<n; i++)
	{
		scanf("%d", &arr[i]);
		large = arr[0];
	}
	printf("\nELEMENTS OF ARRAY ARE : \n");
	for(i=0; i<n; i++)
	{
		printf("%d\t", arr[i]);
	}
	large = arr[0];
	for(i = 1; i < n; i++)
    	{
        	if(large < arr[i])  
        	{
            	large = arr[i]; 
        	}
    	} 
    printf("\n\nLARGEST ELEMENT OF THE ARRAY IS : \n");
    printf("%d", large);
	return 0;
}
