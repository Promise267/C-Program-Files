 #include<stdio.h>
#include<conio.h>
int main()
{
	int arr1[100],arr2[100],arr3[200],n1,n2,i,j,tempdes;
	printf("		PROGRAM TO ADD TWO ONE DIMENSIONAL ARRAYS AND DISPLAY ELEMENTS OF THIRD IN ASCENDING ORDER\n");
	printf("					(NOTE : ARRAY SIZE MUST NOT EXCEED 100)\n");
	printf("------------------------------------------------------------------------------------------------------------------------\n");
	
	printf("ENTER SIZE OF ARRAY 1 : \n");
	scanf("%d", &n1);
	printf("ENTER %d ELEMENTS : \n", n1);
	for(i=0; i<n1; i++)
	{
		scanf("%d", &arr1[i]);
	}
	
	printf("ENTER SIZE OF ARRAY 2: \n");
	scanf("%d", &n2);
	printf("ENTER %d ELEMENTS : \n", n2);
	for(i=0; i<n2; i++)
	{
		scanf("%d", &arr2[i]);
	}
	
	printf("\n\nELEMENTS OF ARRAY 1 ARE :\n");
	for(i=0; i<n1; i++)
	{
    	printf("%d\t", arr1[i]);

    }
    
	printf("\n\nELEMENTS OF ARRAY 2 ARE :\n");
	for(i=0; i<n2; i++)
	{
    	printf("%d\t", arr2[i]);
    }
    
    for(i=0; i<n1; i++)
    {
        arr3[i] = arr1[i];
    }
    for(j=0; j<n2; j++)
    {
        arr3[i] = arr2[j];
        i++;
    }
	printf("\n\nELEMENTS OF ARRAY 3 ARE :\n");
	for(i=0; i<(n1+n2); i++)
	{
    	printf("%d\t", arr3[i]);
    }
    
    for(j=0; j<(n1+n2); j++)
    {
        for(i=0; i<(n1+n2); i++)
        {
            if(arr3[i]>arr3[j])
            {
                tempdes = arr3[i];
                arr3[i] = arr3[j];
                arr3[j] = tempdes;
            }
        }
    }
    
    printf("\n\nELEMENTS OF ARRAY 3 IN ASCENDING ORDER :\n");
    for(i=0; i<(n1+n2); i++)
    {
        printf("%d\t", arr3[i]);
    }
    return 0;
}
