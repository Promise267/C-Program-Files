#include<stdio.h >
#include<string.h>
int main()
{
char str[50][30],temp[30];
int i,j,n;
	printf("ENTER THE NUMBER OF STUDENTS :\n");
	scanf("%d",&n);
	printf("\nENTER NAME OF %d STUDENTS:\n",n);
	for(i=0;i<n;i++)
	{
		scanf("%s",str[i]);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(strcmp(str[i],str[j])>0)
			{
				strcpy(temp,str[i]);
				strcpy(str[i],str[j]);
				strcpy(str[j],temp);
			}
		}
	}
	printf("THE SORTED NAMES OF STUDENTS ARE ");
	for(i=0;i<n;i++)
	{
		printf("\n%s",str[i]);
	}
	return 0;
}
