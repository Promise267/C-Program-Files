#include <stdio.h>
void main()
{
    int i,j,arr1[50][50],r , c, sum=0;
	 
    printf("\n			PROGRAM TO DISPLAY SUM OF SQUARE OF THE DIAGONAL OF A SQAURE MATRIX\n");
    printf("------------------------------------------------------------------------------------------------------------------------\n");	 
	 
	printf("ENTER ROW AND COLUMN OF MATRIX  :\n");
    scanf("%d%d", &r, &c);
	while(r != c)
	{
		printf("INVALID! THE ORDER OF MATRIX IS NOT SQUARE MATRIX. TRY AGAIN\n");
    	printf("------------------------------------------------------------------------------------------------------------------------\n");
		printf("ENTER ROW AND COLUMN OF MATRIX  :\n");
    	scanf("%d%d", &r, &c);
	} 
	printf("ENTER ELEMENTS OF FIRST MATRIX  :\n");
    	for(i=0;i<r;i++)
    	{
        	for(j=0;j<c;j++)
        	{
	        	printf("ENTER ELEMENT a%d%d : ",i+1,j+1);
	        	scanf("%d",&arr1[i][j]);
        	}
    	}  
	printf("ENTERED MATRIX IS :\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c ;j++)
	    printf("%d\t",arr1[i][j]);
		printf("\n");
	}
	printf("SQUARE OF ELEMENTS OF ENTERED MATRIX IS :\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c ;j++)
	    printf("%d\t",(arr1[i][j])*(arr1[i][j]));
		printf("\n");
	}
	
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
        {
            if (i == j) 
            {
            sum = sum + (arr1[i][j])*(arr1[i][j]);
            }
        }
	}
       printf("ADDITION OF SQUARE OF ELEMENTS OF DIAGONAL :%d\n",sum);
}
