#include<stdio.h>
#include<conio.h>
int main()
{
	int arr[10], i, j, n, count = 0;
	printf("		PROGRAM TO FIND NUMBERS OF PAIRS OF INTEGERS WHOSE SUM IS 10 OUT OF 10 ARRAY ELEMENTS \n");
	printf("-----------------------------------------------------------------------------------------------------------------------\n");
	printf("ENTER ARRAY ELEMENTS : \n");
	for(i=0; i<10; i++)
	{
		scanf("%d", &arr[i]);
	}
	for (i=0;i<n;i++)
	{
		for (j=i+1;j<n;j++)
		{
			if(arr[i] + arr[j] == 10)
			{
				count++;
			}
		}
	}
	printf("THE PAIRS OF INTEGERS IN ARRAY ELEMENT WHOSE SUM IS EQUAL TO 10 IS : %d", count);
	return 0;
}
