#include<stdio.h>
#include<string.h>
int main()
{
    char line[100];
	int count=0,i,j,l;
    printf("ENTER A SENTENCE:\n");
    gets(strupr(line));
    l = strlen(line);
    for(i=0; i<l ; i++)
    {
        if((line[i]=='a' || line[i]=='e' || line[i]=='i' || line[i]=='o' || line[i]=='u') && (line[i+1]=='a' || line[i+1]=='e' || line[i+1]=='i' || line[i+1]=='o' || line[i+1]=='u'))
        {
            count++;
		}
    }             
    printf("\n\nTHE NUMBER OF SIMULATANEOUS OCCURANCE OF TWO VOWELS ARE = %d", count);
    getch();
    return 0;
}
