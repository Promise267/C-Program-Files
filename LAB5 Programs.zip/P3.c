
#include<stdio.h>
#include<conio.h>
int main()
{
	int arr[100], i, n, pos= 0, neg = 0, odd = 0, even = 0, zero = 0;
	printf("	PROGRAM TO FIND THE NUMBERS OF POSITIVE, NEGATIVE, ODD AND EVEN NUMBER IN A SET OF NUMBERS\n");
	printf("				(NOTE : ARRAY SIZE MUST NOT EXCEED 100)\n");
	printf("--------------------------------------------------------------------------------------------------------------------\n");
	printf("\nENTER ARRAY SIZE : \n");
	scanf("%d", &n);
	printf("\nENTER %d ARRAY ELEMENTS : \n", n);
	for(i=0; i<n; i++)
	{
		scanf("%d", &arr[i]);
        if(arr[i] == 0)  
        {  
            zero++;  
        }  
        else if(arr[i] > 0)  
            pos++;  
        else  
            neg++;  
  
        if(arr[i] == 0)  
        {  
  
        }  
        else if(arr[i] % 2 == 0)  
            even++;  
        else  
            odd++;
	}
    printf("\nNUMBER OF POSITIVE ELEMENTS : %d\n", pos);  
    printf("NUMBER OF NEGATIVE ELEMENTS : %d\n", neg);  
    printf("NUMBER OF EVEN ELEMENTS : %d\n", even);  
    printf("NUMBER OF ODD ELEMENTS : %d\n", odd); 
	return 0;
}
