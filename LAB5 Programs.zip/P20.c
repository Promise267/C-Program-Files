#include<stdio.h>
#include<string.h>
	void main()
	{
  	int i,n;
  	char a[10],b[10],c[10];
 	printf("ENTER YOUR FIRST NAME : \n");
 	scanf("%s",&a[i]);
 	printf("ENTER MIDDLE NAME : \n");
 	scanf("%s",&b[i]);
 	printf("ENTER YOUR LAST NAME : \n");
 	scanf("%s",&c[i]);

 	printf("YOUR NAME AFTER ABBREVIATION : \n");
 	printf("%c",a[0]);
 	printf(".");
  	printf("%c",b[0]);
	printf(".");
  	n=strlen(c);

  	for(i=0;i<=n;i++)
  	{
  		printf("%s",c[i]);
	}
}
