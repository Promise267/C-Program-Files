#include<stdio.h>
int main()
{
	int a[10][10], b[10][10], product[10][10], i, j, k, r1, r2, c1, c2;
	printf("ENTER ROW AND COLUMN OF MATRIX A: \n");
	scanf("%d%d", &r1,&c1);
	printf("\nENTER ROW AND COLUMN OF MATRIX B: \n");
	scanf("%d%d", &r2,&c2);
	while(c1!=r2)
	{
		printf("\nINVALID COLUMN OF MATRIX A IS NOT EQUAL TO MATRIX B. TRY AGAIN!\n");
		printf("----------------------------------------------------------------------------------------------------------------\n");
		printf("\nENTER ROW AND COLUMN OF FIRST MATRIX : \n");
		scanf("%d%d", &r1,&c1);
		printf("ENTER ROW AND COLUMN OF SECOND MATRIX : \n");
		scanf("%d%d", &r2,&c2);
	}
	printf("\nENTER MATRIX A ELEMENTS : \n");
	for(i=0; i<r1; ++i)
	{
		for(j=0; j<c1; ++j)
		{
			printf("ENTER ELEMENT a%d%d : ", i+1, j+1);
			scanf("%d", &a[i][j]);		
		}
	}
	printf("\nENTER MATRIX B ELEMENTS : \n");
	for(i=0; i<r2; ++i)
	{
		for(j=0; j<c2; ++j)
		{
			printf("ENTER ELEMENT b%d%d : ", i+1, j+1);
			scanf("%d", &b[i][j]);		
		}
	}
	printf("\nENTERED MATRIX A: \n");
	for (i = 0; i < r1; ++i)
	{
		for (j = 0; j < c1; ++j) 
		{
			printf("%d  ", a[i][j]);
    		if (j == c1 - 1)
    		printf("\n");
    	}
	}
	printf("\nENTERED MATRIX B: \n");
	for (i = 0; i < r2; ++i)
	{
		for (j = 0; j < c2; ++j) 
		{
			printf("%d  ", b[i][j]);
    		if (j == c2 - 1)
    		printf("\n");
    	}
	}
    for(i=0;i<r1;++i)
    {
    	for(j=0;j<c2;++j)
    	{
			product[i][j] = 0;
		}	
	}
	for(i=0; i<r1; ++i)
	{
		for(j=0; j<c2; ++j)
		{
			for(k=0; k<c1; ++k)
			{
				product[i][j] += a[i][k] * b[k][j];
			}
		}
	}
    printf("\nPRODUCT OF FIRST AND SECOND MATRICES :\n");
    for(i=0;i<r1;++i)
    {
    	for(j=0;j<c2;++j)
    	{
			printf("%d  ",product[i][j]);
			if (j == c2 - 1)
			{
				printf("\n\n");
			}
		}
	}
	return 0;
}
