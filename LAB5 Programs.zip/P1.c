#include<stdio.h>
int main()
{
	int arr[100], i, j, n, tempdes, large, small ,average;
	printf("		PROGRAM TO DISPLAY ARRAY IN DESCENDING ORDER AND AVERAGE OF LARGEST AND SMALLEST VALUE \n");
	printf("				(NOTE : ARRAY SIZE MUST NOT BE GREATER THAN 100) \n");
	printf("------------------------------------------------------------------------------------------------------------------------\n");
	printf("enter array size : \n");
	scanf("%d", &n);
	if (n<=0 || n>100)
	{
		printf("invalid");
		return 0;
	}
	printf("enter %d integers : \n", n);
	for(i=0; i<n; i++)
	{
		scanf("%d", &arr[i]);
		large = arr[0];
	}
	for(i=0;i<n;i++)
	{		
		for(j=i+1;j<n;j++)
		{
			if(arr[i]<arr[j])
			{
				tempdes=arr[i];
				arr[i]=arr[j];
				arr[j]=tempdes;
			}
		}
	}
	printf("Descending Order Array Elements : \n");
	for(i=0;i<n;i++)
	{
		printf(" %d\t", arr[i]);
	}
	large = arr[0];
	for(i = 1; i < n; i++)
    	{
        	if(large < arr[i])  
        	{
            	large = arr[i]; 
        	}
    	}
    small = arr[0];   
    for(i = 1; i <n; i++)
    	{
        	if(small > arr[i])  
        	{
            	small = arr[i];   
        	}
    	}
    printf("\nAverage of Largest number %d and Smallest number %d = %d",large,small, (large+small)/2);	
	return 0;
}

