#include<stdio.h>
#include<conio.h>
int main()
{
	int arr[100], i, j, n, search, found;
	printf("					PROGRAM TO SEARCH A NUMBER IN THE GIVEN ARRAY\n");
	printf("					  (NOTE : ARRAY SIZE MUST NOT EXCEED 100)\n");
	printf("-----------------------------------------------------------------------------------------------------------------------\n");
	printf("ENTER ARRAY SIZE :\n");
	scanf("%d", &n);
	printf("\nENTER %d ARRAY ELEMENTS :\n", n);
	for(i=0;i<n;i++)
	{
		scanf("%d", &arr[i]);
	}
    printf("\nENTER ELEMENT TO SEARCH :\n");
    scanf("%d", &search);

    found = 0; 
    
    for(i=0; i<n; i++)
    {
        if(arr[i] == search)
        {
            found = 1;
            break;
        }
    }
    if(found == 1)
    {
        printf("\n%d IS FOUND AT INDEX %d", search, i + 1);
    }
    else
    {
        printf("\n%d IS NOT FOUND IN ARRAY", search);
    }
    return 0;
}
