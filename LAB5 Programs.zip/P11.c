#include <stdio.h>
 int main()
{
    int array1[10][10], array2[10][10],i, j, k, a, m, n;
 
    printf("ENTER ROW AND COLUMN OF MATRIX : \n");
    scanf("%d %d", &m, &n);
    printf("ENTER MATIX ELEMENTS : \n");
    for (i = 0; i < m; ++i)
    {
        for (j = 0; j < n; ++j)
        {
            scanf("%d", &array1[i][j]);
            array2[i][j] = array1[i][j];
        }
    }
    printf("ENTERED MATRIX IS :\n");
    for (i = 0; i < m; ++i)
    {
        for (j = 0; j < n; ++j)
        {
                printf(" %d", array1[i][j]);
        }
        printf("\n");
    }
    printf("MATRIX ARRANGED IN DESCENDING ORDER\n");
    for (i = 0; i < m; ++i)
    {
        for (j = 0; j < n; ++j)
        {
            for (k =(j + 1); k < n; ++k)
            {
                if (array1[i][j] < array1[i][k])
                {
                    a = array1[i][j];
                    array1[i][j] = array1[i][k];
                    array1[i][k] = a;
                }
            }
        }
    }
    for (i = 0; i < m; ++i)
    {
        for (j = 0; j < n; ++j)
        {
            printf(" %d", array1[i][j]);
        }
        printf("\n");
    }
    return 0;
}

