#include<stdio.h>
int main()
{
	int a[10][10], b[10][10], sum[10][10], diff[10][10], r, c, i, j;
	printf("ENTER ROW AND COLUMN OF MATRIX :\n");
	scanf("%d%d", &r,&c);
	printf("\nENTER ELEMENTS OF FIRST MATRIX : \n");
	for(i=0; i<r; i++)
	{
		for(j=0;j<c;j++)
		{
			printf("ENTER ELEMENT a%d%d : ", i+1, j+1);
			scanf("%d", &a[i][j]);
		}
	}
	printf("\nENTER ELEMENTS OF SECOND MATRIX : \n");
	for(i=0; i<r; i++)
	{
		for(j=0;j<c;j++)
		{
			printf("ENTER ELEMENT b%d%d : ", i+1, j+1);
			scanf("%d", &b[i][j]);
		}
	}
	printf("\nENTERED ELEMENTS OF FIRST MATRIX IS : \n");
	for(i=0; i<r; i++)
	{
		for(j=0; j<c; j++)
		{
			printf("  %d", a[i][j]);
			if( j == c - 1)
			printf("\n\n");
		}
	}
	printf("\nENTERED ELEMENTS OF SECOND MATRIX IS : \n");
	for(i=0; i<r; i++)
	{
		for(j=0; j<c; j++)
		{
			printf("  %d", b[i][j]);
			if( j == c - 1)
			printf("\n\n");
		}
	}
	
	for(i=0; i<r; i++)
	{
		for(j=0;j<c;j++)
		{
			sum[i][j] = a[i][j] + b[i][j];
		}
	}
	for(i=0; i<r; i++)
	{
		for(j=0;j<c;j++)
		{
			diff[i][j] = a[i][j] - b[i][j];
		}
	}
	printf("\nSUM OF TWO MATRICES :\n");
	for(i=0; i<r; i++)
	{
		for(j=0;j<c;j++)
		{
			printf("  %d", sum[i][j]);
			if (j == c - 1)
			{
				printf("\n\n");
			}
		}
	}
	printf("\nDIFFERENCE OF TWO MATRICES :\n");
	for(i=0; i<r; i++)
	{
		for(j=0;j<c;j++)
		{
			printf("  %d", diff[i][j]);
			if (j == c - 1)
			{
				printf("\n\n");
			}
		}
	}
	return 0;
}
