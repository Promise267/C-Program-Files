#include<stdio.h>
#include<string.h>
int main()
{
	int opt, i;
	char ch1[100], ch2[100], v;
	printf("					WELCOME TO MY PROGRAM MENU DRIVEN PROGRAM\n");
	printf("					NOTE : STRING SIZE MUST NOT EXCEED 100\n");
 	printf("------------------------------------------------------------------------------------------------------------------------\n");
	printf("\nENTER YOUR OPTION :\n\n1.Convert lowercase string into uppercase\n2.Convert uppercase string into lowercase\n3.Calculate length of the given string\n4.Reverse the given string\n5.Copy one string into another\n6.Concatenate two strings into one string\n7.Compare two string\n8.Exit\n\n");
	scanf("%d", &opt);
	switch(opt)
	{
		case 1:
		{
			printf("\nENTER A STRING : ");
			scanf("%s", &ch1);
			printf("\nTHE STRING IN UPPERCASE IS : %s",strupr(ch1));
			break;
		}
		case 2:
		{
			printf("\nENTER A STRING : ");
			scanf("%s", &ch1);
			printf("\nTHE STRING IN LOWERCASE IS : %s",strlwr(ch1));
			break;
		}
		case 3:
		{
			printf("\nENTER A STRING : ");
			scanf("%s", &ch1);
			for(i=0;ch1[i]!='\0';i++);
 				printf("\nLENGTH OF THE STRING IS : %d", i);
			break;
		}
		case 4:
		{
			printf("\nENTER A STRING : ");
			scanf("%s", &ch1);
			printf("THE STRING IN REVERSE IS : %s",strrev(ch1));
			break;
		}
		case 5:
		{
			printf("\nENTER A STRING TO BE COPIED TO ANOTHER : ");
			scanf("%s", &ch1);
			printf("THE STRING AFTER BEING COPIED TO ANOTHER : %s", strcpy(ch2,ch1));
			break;
		}
		case 6:
		{
			printf("ENTER FIRST STRING : ");
			scanf("%s", &ch1);
			printf("ENTER SECOND STRING : ");
			scanf("%s", &ch2);
			printf("THE STRING AFTER CONCATENATING TWO STRINGS : %s", strcat(ch1,ch2));
		}
		case 7:
		{
			printf("ENTER FIRST STRING : ");
			scanf("%s", &ch1);
			printf("ENTER SECOND STRING : ");
			scanf("%s", &ch2);
			v = strcmp(ch1, ch2);
			if (v==0)
			{
				printf("BOTH STRINGS ARE SAME");
			}
			else if(v>0)
			{
				printf("%s comes after %s", ch1, ch2);
			}
			else
			{
				printf("%s comes after %s", ch2, ch1);				
			}
			break;
		}
		case 8:
		{
			printf("\nTHANK YOU FOR YOUR VISIT!");
			break;
		}
	}
	return 0;
}
	
