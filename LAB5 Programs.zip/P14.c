#include<stdio.h>
#include<conio.h>
#include<string.h>
int main() 
{	 
	char str[10]; 
	int i,j,n,flag=0; 
	printf("ENTER A STRING : ");
	gets(str); 
	n=strlen(str); 
	for(i=0,j=n-1;i<=n/2;i++,j--) 
	{	 
		if(str[i]!=str[j]) 
		flag=1; 
		break; 
	}	 
		if(flag==1) 
		{
			printf("\nGIVEN STRING '%s' IS NOT PALINDROME.", str); 
		}
		else
		{
			printf("\nGIVEN STRING '%s' IS PALINDROME.", str); 
		}
	getch();
	return 0;
}
