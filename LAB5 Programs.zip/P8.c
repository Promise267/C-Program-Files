#include <stdio.h>
int main() 
{
  int a[10][10], transpose[10][10], r, c, i, j;
  printf("				PROGRAM TO DISPLAY 2X3 MATRIX AND ITS TRANSPOSE\n");
  printf("-----------------------------------------------------------------------------------------------------------------------\n");  
  printf("\nENTER MATRIX ELEMENT:\n");
  for (i = 0; i < 2; ++i)
  for (j = 0; j < 3; ++j) 
  {
    printf("ENTER ELEMENT a%d%d: ", i + 1, j + 1);
    scanf("%d", &a[i][j]);
  }

  printf("\nENTERED MATRIX: \n");
  for (i = 0; i < 2; ++i)
  for (j = 0; j < 3; ++j) 
  {
    printf("%d  ", a[i][j]);
    if (j == 3 - 1)
    printf("\n");
  }

  for (i = 0; i < 2; ++i)
  for (j = 0; j < 3; ++j) 
  {
    transpose[j][i] = a[i][j];
  }

  printf("\nTRANSPOSE OF MATRIX:\n");
  for (i = 0; i < 3; ++i)
  for (j = 0; j < 2; ++j) 
  {
    printf("%d  ", transpose[i][j]);
    if (j == 2 - 1)
    printf("\n");
  }
  return 0;
}
