#include<stdio.h>
#include<string.h>
int main()
{
	char ch[100];
	int i=0, j, chk, count = 0;
	printf("ENTER A STRING : \n");
	gets(ch);
	for(i=0; ch[i] != '\0' ; i++)
	{
		if(ch[i]=='A'||ch[i]=='E'||ch[i]=='I'||ch[i]=='O'||ch[i]=='U'||ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u')
		{
			count++;
		}
		if(ch[i]=='A'||ch[i]=='E'||ch[i]=='I'||ch[i]=='O'||ch[i]=='U'||ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u')
        {
        j=i;
        while(ch[j-1]!='\0')
        	{
            ch[j] = ch[j+1];
            j++;
        	}
        	chk = 1;
        }
        if(chk==0)
            i++;
	}
	printf("\nNUMBER OF VOWELS PRESENT IN THE STRING IS : %d \n", count);
	printf("\nRESULTANT STRING WITHOUT VOWELS : %s", ch);
	getch();
	return 0;
}
