//Write a program to replace a word from a sentence
#include<stdio.h>
#include<conio.h>

int main()
{
	char s1[80],w[20],ch,sw[20],rw[20];
	int i,k;
	clrscr();

	printf("\nEnter string : ");
	gets(s1);

	printf("\nEnter search word : ");
	gets(sw);

	printf("\nEnter replace word : ");
	gets(rw);

	printf("\nOutput = ");
	strcat(s1," ");
	k=0;
	for(i=0;s1[i]!='\0';i++)
	{
		ch=s1[i];
		if(ch!=' ')
		{
			w[k]=ch;
			k++;
		}
		else
		{
			w[k]='\0';
			//printf("\n %s",w);
			k=0;
			if(strcmp(w,sw)==0)
			{
				//strcat(rw," ");
				printf("%s ",rw);
			}
			else
			{
				//strcat(w," ");
				printf("%s ",w);
			}
		}
	}

	getch();
	return 0;
}
