#include <stdio.h>
int main()
{
   int arr[100], i, n, position;
	printf("				PROGRAM TO DELETE THE GIVEN NUMBER IN THE GIVEN ARRAY\n");
	printf("					  (NOTE : ARRAY SIZE MUST NOT EXCEED 100)\n");
	printf("-----------------------------------------------------------------------------------------------------------------------\n");
	printf("ENTER ARRAY SIZE : \n");
	scanf("%d", &n);

	printf("ENTER %d ARRAY ELEMENTS\n", n);
	for (i = 0; i < n; i++)
	{
    	scanf("%d", &arr[i]);
	}

	printf("ENTER THE POSITIONAL LOCATION OF ARRAY ELEMENT TO DELETE :\n");
	scanf("%d", &position);

	if (position >= n+1)
	{
		printf("DELETE NOT POSSIBLE\n");
	}
	else
		for (i = position - 1; i < n - 1; i++)
		{
    		arr[i] = arr[i+1];
    		printf("ARRAY AFTER DELETION OF %d POSITION ARRAY ELEMENT: \n", position);
    		{
    			for (i = 0; i < n - 1; i++)
        		printf("%d\n", arr[i]);
    		}
		}
	return 0;
}

