#include<stdio.h>
#include<string.h>
int main()
{
	char fname[10], mname[10], lname[10];
	int i, n;
	printf("ENTER YOUR FIRST NAME : \n");
	scanf("%s", &fname[i]);
	printf("ENTER YOUR MIDDLE NAME : \n");
	scanf("%s", &mname[i]);
	printf("ENTER YOUR LAST NAME : \n");
	scanf("%s", &lname[i]);
	
	printf("YOUR NAME AFTER ABBREVIATION : \n");
	printf("%c", fname[0]);
	printf(".");
	printf("%c", mname[0]);
	printf(".");
	n = strlen(lname);
	
	for(i = 0; i <= n; i++)
	{
		printf("%c", lname[i]);
	}
}
