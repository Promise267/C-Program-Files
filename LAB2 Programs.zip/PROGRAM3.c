#include<stdio.h>
#include<math.h>
void main()
{
	float x,a,b;
	printf("enter a number whose sqaure and square root is to be displayed:");
	scanf("%f",&x);
	a=pow(x,2);
	b=sqrt(x);
	printf("\n the square of %.2f = %.2f",x,a);
	printf("\n the square root of %.2f = %.2f",x,b);	
}
