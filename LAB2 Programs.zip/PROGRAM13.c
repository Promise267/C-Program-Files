#include <stdio.h>
void main()
{
    int num, sum, ftdigit, ltdigit;
    printf("Enter any number to find sum of first two and last two digits : ");
    scanf("%d", &num);
    ltdigit = num % 100;
    ftdigit = num;
    while(num >= 100)
    num = num / 10;
    ftdigit = num;
    sum = ftdigit + ltdigit;
    printf("Sum of first two and last two digit = %d", sum);
}
