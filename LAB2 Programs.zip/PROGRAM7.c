#include<stdio.h>
void main()
{
	int a,b;
	printf("enter the first value to be assigned in variable a : ");
	scanf("%d", &a);
	printf("enter the second value to be assigned in variable b: ");
	scanf("%d", &b);
	a=a+b;
	b=a-b;
	a=a-b;
	printf("the required program after swapping two numbers is a = %d b = %d",a,b);
}
