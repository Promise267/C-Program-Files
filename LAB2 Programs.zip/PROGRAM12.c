#include <stdio.h>
void main()
{
    int num, sum, fdigit, ldigit;
    printf("Enter any number to find sum of first and last digit : ");
    scanf("%d", &num);
    ldigit = num % 10;
    fdigit = num;
    while(num >= 10)
    num = num / 10;
    fdigit = num;
    sum = fdigit + ldigit;
    printf("Sum of first and last digit = %d", sum);
}
