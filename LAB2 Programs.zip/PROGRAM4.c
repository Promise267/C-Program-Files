#include<stdio.h>
void main()
{
	float p,t,r,s,a;
	printf("enter the principle amount:");
	scanf("%f",&p);	
	printf("enter the time:");
	scanf("%f",&t);	
	printf("enter the the rate:");
	scanf("%f",&r);
	s=(p*t*r)/100;
	a=p+s;
	printf("\n the simple interest of the given data = %.2f",s);
	printf("\n the total amount of the given data = %.2f",a);
}
