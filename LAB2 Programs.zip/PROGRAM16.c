#include <stdio.h>
void main( )
{
    int c;
    printf("Enter a character : ");
    c = getchar();
    putchar(c);
}
