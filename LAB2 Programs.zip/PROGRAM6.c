#define PI 3.141
#include<stdio.h>
void main()
{
	float r,c;
	printf("enter the radius of circle : ");
	scanf("%f",&r);
	c=2*PI*r;
	printf("the circumference of radius %f = %f", r, c);
}
