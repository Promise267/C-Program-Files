#include<stdio.h>
#include<math.h>
void main()
{
	float a,b,c,s,area,x;
	printf("enter the first side of the triangle : ");
	scanf("%f",&a);
	printf("enter the second side of the triangle : ");
	scanf("%f",&b);
	printf("enter the third side of the triangle : ");
	scanf("%f",&c);
	s=(a+b+c)/2;
	area=s*(s-a)*(s-b)*(s-c);
	x=sqrt(area);
	printf("the area of the triangle with sides %.2f, %.2f and %.2f = %.2f",a,b,c,x);
}
