#include<stdio.h>
void main()
{
	float f,c;
	printf("enter the temperature in degree fahrenheit:");
	scanf("%f",&f);
	c= (f-32)*5/9;
	printf("the conversion of temperture from degree fahrenheit into degree celsius is = %.2f", c);
}
