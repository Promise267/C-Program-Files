#include<stdio.h>
void main()
{
	float p,r;
	printf("enter the cost of book in paisa to convert it into rupees : ");
	scanf("%f", &p);
	r=(p/100);
	printf("the cost of the book in rupee from paisa is Rs. %.2f",r);
}
