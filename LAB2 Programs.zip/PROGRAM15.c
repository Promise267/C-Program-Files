#include<stdio.h>
#include<conio.h>
#include<math.h>
#define PI 3.141592
void main()
{
	 float x, y, r, theta;
	 printf("Enter radius of polar coordinate (r): ");
	 scanf("%f", &r);
	 printf("Enter angle of polar coordinate in degree (theta): ");
	 scanf("%f", &theta);
	 theta = theta * PI/180.0;
	 x = r * cos(theta);
	 y = r * sin(theta);
	 printf("Cartesian coordinates is: (%0.3f, %0.3f)", x, y);
}
