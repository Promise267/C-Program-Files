#include<stdio.h>
void main()
{
	int a,b,s,d,p,q,r;
	printf("enter first integer:");
	scanf("%d",&a);
	printf("enter second integer:");
	scanf("%d",&b);
	s=a+b;
	d=a-b;
	p=a*b;
	q=a/b;
	r=a%b;
	printf("\n sum of %d and %d = %d", a,b,s);
	printf("\n difference of %d and %d = %d", a,b,d);
	printf("\n product of %d and %d = %d", a,b,p);
	printf("\n quotient of %d and %d = %d", a,b,q);
	printf("\n remainder of %d and %d = %d", a,b,r);
}
