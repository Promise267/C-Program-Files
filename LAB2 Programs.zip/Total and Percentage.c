#include<stdio.h>
void main()
{
	int a,b,c,d,m,total;
	float percentage;
	printf("Enter your marks in AE&SS  : ");
	scanf("%f",&a);
	printf("Enter your marks in ITP : ");
	scanf("%f",&b);
	printf("Enter your marks in	 CFN : ");
	scanf("%f",&c);
	printf("Enter your marks in FODS  : ");
	scanf("%f",&d);
	if (a>=35&&b>=35&&c>=35&&d>=35)
			total=(a+b+c+d);
			percentage=(float)(a+b+c+d)/4;
			{	if (percentage>=75)
			printf("\nYou scored Distinction");
		
			else if (percentage>=60)
			printf("\nYou scored First Division");

			else if (percentage>=45)
			printf("\nYou scored Second Division");

			else
			printf("\nYou scored Third Division");
		
		}
	else
		printf("\nYou Failed");
}
