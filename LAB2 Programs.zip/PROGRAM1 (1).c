#include <stdio.h>
void main() 
{
	printf("this is my first program in C");
}
