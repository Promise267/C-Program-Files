#include<stdio.h>
#include<math.h>
void main()
{
	float p,b,x,y,h,t;
	printf("enter the length of perpendicular : ");
	scanf("%f",&p);
	printf("enter the length of base : ");
	scanf("%f",&b);
	x=pow(p,2);
	y=pow(b,2);
	h=x+y;
	t=sqrt(h);
	printf("the length of hypoteneuse of the right angeled triangle = %.2f",t);
}
