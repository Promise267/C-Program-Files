#include <stdio.h>
int nonr(int no);
int r(int no);
void main()
{
 int no,factorial;
  	printf("ENTER A NUMBER TO CALCULATE FACTORIAL\n");
  	scanf("%d",&no);
  	nonr(no);
  	factorial = r(no);
    printf("\nFACTORIAL OF NUMBER USING RECURSION = %d",factorial);
}
	int nonr(int no)
	{
    	int i,f=1;
    	for(i=1;i<=no;i++)
    	{
        	f=f*i;
    	}
    	printf("\nTHE FACTORIAL OF NUMBER WITHOUT USING RECUSRSION IS : %d", f);
	}
	int r(int no) 
	{
		int a, factorial;
    	if (no>=1)
    	{
        	return no*factorial*(no-1);
        }
    	else
    	{
        	return factorial;
        }
	}
