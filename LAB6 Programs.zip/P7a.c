#include<stdio.h>
int nonr(int n);
int r(int n);
void main()
{
	int n, rsum;
	printf("ENTER ANY NUMBER : ");
	scanf("%d", &n);
	nonr(n);
	rsum = r(n);
	printf("\nTHE SUM OF THE DIGITS (USING RECUSRION) IS %d", rsum);	
}
int nonr(int n)
{
	int i, sum=0;
	while(n>0)
	{
		i = n / 10;
		sum = sum + i;
		n = n / 10;
	}
	printf("\nTHE SUM OF DIGITS (USING NON RECUSRSION) IS %d", sum);
}
	int r(int n)
	{
		if(n==0)
		{
			return 0;
		}
		else
		{
			return ((n%10)+r(n/10));
		}
	}
