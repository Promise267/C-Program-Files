#include <stdio.h>
int pnz();

int main()
{
    int n;
    n = pnz();    
    if (n > 0)
        printf("%d IS POSITIVE NUMBER ", n);
    else if (n < 0)
        printf("%d IS NEGATIVE NUMBER", n);
    else
    	printf("%d IS ZERO", n);

    return 0;
}
int pnz()       
{
    int n;

    printf("Enter a integer: ");
    scanf("%d",&n);
    return n;
}
