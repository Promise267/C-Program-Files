#include<stdio.h>
void sort(int x[], int n);
int main()
{	int i,n, x[10];
	printf("Enter the size of array not more than 10 :");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{	printf("Enter array element %d : ", i + 1);
		scanf("%d",&x[i]);
	}
	sort(x,n);
	return 0;
}
void sort(int x[],int n)
{
		int i,j,temp;
	   	for(i=0;i<n-1;i++)
	   	{	for(j=i+1;j<n;j++)
	 		{	if(x[i]>x[j])
    				{	temp=x[i];
	 	 			x[i]=x[j];
 			 		x[j]=temp;
	 			}
	 		}
	   	}
	   	printf("\nNumbers in ascending order are : \n");
	   	for(i=0;i<n;i++)
	   		printf("%d\n",x[i]);
}

