#include <stdio.h>
#include <string.h>
int sorting(int count);
int main()
{
	int count;
	printf("HOW MANY STRINGS U WANT TO ENTER?\n");
	scanf("%d", &count);
	sorting(count);
	return 0;
}
int sorting (int count)
{
	int i,j;
	char str[100][100],temp[100];
	puts("ENTER STRINGS ONE BY ONE : ");
	for(i=0; i<= count; i++)
		gets(str[i]);
	for(i=0; i<=count; i++)
	{
		for(j=i+1; j<=count; j++)
		{
			if(strcmp(str[i],str[j])>0)
			{
				strcpy(temp,str[i]);
				strcpy(str[i], str[j]);
				strcpy(str[j], temp);
			}
		}
	}
	printf("ORDER OF SORTED STRINGS : ");
	for(i=0; i<=count; i++)
	{
		puts(str[i]);
	}
}
 
