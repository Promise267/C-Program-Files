 #include<stdio.h>
#include<conio.h>
void transpose(int a[3][3],int n);
void main()
{
	int a[3][3],trans[3][3];
	int i,j,n;
	printf("ENTER MATRIX SIZE : \n");
	scanf("%d",&n);;
	for(i=0;i<n;i++)
	{
 		for(j=0;j<n;j++)
  		{
			printf("ENTER MATRIX ELEMENTa[%d][%d] : \n", i+1,j+1);
  			scanf("%d", &a[i][j]);
  		}
 	}
  	transpose(a,n);
	getch();
}
void transpose(int a1[3][3],int n1)
{
	int trans[3][3];
	int i,j;
	for(i=0;i<n1;i++)
 	{
 		for(j=0;j<n1;j++)
  		{
  			trans[i][j]=a1[j][i];
  		}
 	}
	printf("\n THE TRANSPOSE OF MATRIX IS \n");
	for(i=0;i<n1;i++)
 	{
 		for(j=0;j<n1;j++)
  		{
		printf("\t%d",trans[i][j]);
  		}
		printf("\n");
	}
	getch();
}
