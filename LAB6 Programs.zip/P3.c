#include <stdio.h>
int avg();
int main()
{
    int i, n, sum;
    float aveg;
    n = avg();
	for (i=0; i<=n; i++)
	{
		sum = sum + i;
	}
	aveg = (sum / 5);
	printf("THE AVERAGE OF 5 NUMBERS ARE : %.2f", aveg);
    return 0;
}
int avg()       
{
    int i, n;
    printf("ENTER 5 NUMBERS : ");
	for(i = 0; i < 5; i++)
	{
    	scanf("%d",&n);
	}
	return n;
}
	
