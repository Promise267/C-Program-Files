#include<stdio.h>
int nonr(int a, int b, int n);
int r(int n);
void main()
{
	int a = 1, b = 2, n, i, result;
	printf("ENTER NUMBER OF TERMS : ");
	scanf("%d", &n);
	printf("THE FIBONACCI SERIES USING RECUSRION :\n");
	for(i=0; i<=n; i++)
	{
		printf("%d\t", r(i));
	}
	printf("\n THE FIBONACCI SERIES USING NON RECUSRION IS: \n");
	nonr(a,b,n);
}
int nonr(int a,int b, int n)
{
	int i,z;
	for(i = 1; i<=n; i++)
	{
		printf("%d\t", a);
		z = a + b;
		a = b;
		b = z;
	}
}
int r(int n)
{
	if(n==0)
		return 0;
	else if(n==1)
		return 1;
	else
		return (r(n-1)+r(n-2));
}
