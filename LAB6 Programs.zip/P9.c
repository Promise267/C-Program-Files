 #include <stdio.h>
#include <string.h>
void ispalindrome(char *str)
{
	char *revstr, *startstr;
	int stringlength = strlen(str);
	int i, flag = 0;
	startstr = str;
	for(i = 0; i < stringlength - 1; i++)
		str++;
	revstr = str;
	while(startstr < revstr)
	{
		if(*startstr != *revstr)
			flag = 1;
		startstr++;
		revstr--;
	}
	if(flag == 0)
		printf("\nEntered string is a palindrome string");
	else
		printf("\nEntered string is not a palindrome string");
}
 
int main(int argc, char **argv)
{
	char str[20];
	printf("Enter a string: ");
	gets(str);
	printf("\n");
	ispalindrome(str);
    getch();
    return 0;
}
