#include<stdio.h>
int sum(int a, int b);
int diff(int a, int b);
int pro(int a, int b);
int quo(int a, int b);
int rem(int a, int b);					
int main()	
{
	int a, b; 
	printf("ENTER FIRST NUMBER : \n");
	scanf("%d",&a);
	printf("ENTER SECOND NUMBER : \n");
	scanf("%d",&b);
	
	printf("\nSUM OF %d and %d = %d",a, b, sum(a, b));
	printf("\nDIFFERENCE OF %d and %d = %d",a, b, diff(a, b));
	printf("\nPRODUCT OF %d and %d = %d",a, b, pro(a, b));
	printf("\nQUOTIENT OF %d and %d = %d",a, b, quo(a, b));
	printf("\nREMAINDER OF %d and %d = %d",a, b, rem(a, b));
	
	return 0;
} 
int sum(int a, int b)
{
	int result; 			 
	result = a + b;
	return result;
}
int diff(int a, int b)
{
	int result; 			 
	result = a - b;
	return result;
}
int pro(int a, int b)
{
	int result; 			 
	result = a * b;
	return result;
}
int quo(int a, int b)
{
	int result; 			 
	result = a / b;
	return result;
}
int rem(int a, int b)
{
	int result; 			 
	result = a % b;
	return result;
}

