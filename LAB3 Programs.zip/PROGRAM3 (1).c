#include<stdio.h>
void main()
{
	int cp,sp;
	printf("enter the cost price : ");
	scanf("%d",&cp);
	printf("enter the selling price : ");
	scanf("%d",&sp);
	if (cp>sp)
		printf("Loss");
	else
		printf("Profit");
}
