 #include<stdio.h>
#include<ctype.h>
 void main()
{
    char ch;
    printf("enter a character to convert uppercase into lowercase and vice-versa : ");
    scanf("%c",&ch);
    if (ch>=65 && ch<=90)
    	printf("the conversion of the letter %c to lower case is = %c ", ch, tolower(ch));
    else if (ch>=97 && ch<=122)
    	printf("the conversion of the letter %c to upper case is = %c ", ch, toupper(ch));
    else
    	printf("False character enter only single alphabet");
}
 
