#include<stdio.h>
void main()
{
	int a;
	printf("enter a whole number : ");
	scanf("%d", &a);
	if (a%2==0)
		printf("the given number is even");
	else
		printf("the given number is odd");	
}
