
#include<stdio.h>
void main()
{
	int opt,year;
	float a,l,b,area,perimeter;
START :
	printf("ENTER ONE OF THE FOLLOWING OPTION :\n");
	printf("-----------------------------------------------\n");
	printf("1. CALCULATE AREA AND PERIMETER OF A RECTANGLE\n2. CHECK WETHER THE GIVEN NUMBER IS POSITIVE, NEGATIVE OR ZERO\n3. CHECK WETHER THE GIVEN YEAR IS LEAP YEAR OR NOT\n4.EXIT \n: ");
	scanf("%d", &opt);
	switch(opt)
	{
		case 1:
			printf("Enter the Length Of the Rectangle in metre : ");
			scanf("%f",&l);
			printf("Enter the Breadth Of the Rectangle in metre: ");
			scanf("%f",&b);
			area=l*b;
			perimeter=2*(l+b);
			printf("the area of the rectangle with length %.2f m and breadth %.2f m = %.2f m^2\n", l, b, area);
			printf("the perimeter of the rectangle with length %.2f m and breadth %.2f m = %.2f m", l, b, perimeter);
			break;
			
		case 2:
			printf("enter a number : ");
			scanf("%f", &a);
			if (a>0)
				printf("the given number %.2f is positive", a);
			else if (a<0)
				printf("the given number %.2f is negative", a);
			else
				printf("the given number is zero");
			break;
				
		case 3:
			printf("enter the year : ");
			scanf("%d", &year);
			if (year%4==0)
				printf("the given year %d is a leap year", year);
			else
				printf("the given year %d is not a leap year", year);
			break;
			
		case 4:
			printf("THANK YOU FOR USING OUR PROGRAM");
			break;
			
		default:
			printf("INVALID OPTION ENTERED, TRY AGAIN \n");
			goto START;
			break;
	}
}
