#include<stdio.h>
#include<math.h>
void main()
{
	float h, k, radius, x, y, distance;
	printf("enter centre coordinates (h,k) of the circle : ");
	scanf("%f%f", &h,&k);
	printf ("enter the co-ordinate from where the distance is to be found out (x,y) : ");
	scanf("%f%f", &x,&y);
	printf("enter the radius of circle : " );
	scanf("%f", &radius);
	distance = sqrt ( pow ( x-h , 2 ) + pow ( y-k , 2 ) ) ;
	if (distance>radius)
		printf("the given co-ordinates (%.2f,%.2f) lies outside the circle", x,y);
	else if (distance<radius)
		printf("the given co-ordinates (%.2f,%.2f) lies inside the circle", x,y);
	else if (distance=radius)
		printf("the given co-ordinates (%.2f,%.2f) lies on the circle",x,y);
	else
		printf("wrong entry"); 
}
