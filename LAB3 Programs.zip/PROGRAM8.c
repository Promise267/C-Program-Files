#include<stdio.h>
void main()
{
	char ch;
	printf("enter an alphabet : ");
	scanf("%c", &ch);
	if( ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
		printf("the given alphabet %c is vowel ", ch);
	else
		printf("the given alphabet %c is consonant ", ch);
}
