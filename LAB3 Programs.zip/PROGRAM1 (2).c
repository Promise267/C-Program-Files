#include<stdio.h>
void main()
{
	float a,b;
	printf("enter the first number : ");
	scanf("%f", &a);
	printf("enter the second number : ");
	scanf("%f", &b);
	if (a>b)
		printf("the largest number is = %.2f", a);
	else
		printf("the largest number is = %.2f", b);

}
