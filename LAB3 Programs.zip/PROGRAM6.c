#include<stdio.h>  
  
void main()  
{  
    float x1, y1, x2, y2, x3, y3, a, b;  
  
    printf("\nEnter first points (x1, y1)\n");  
    scanf("\n%f%f", &x1, &y1);  
  
    printf("\nEnter second points (x2, y2)\n");  
    scanf("\n%f%f", &x2, &y2);  
  
    printf("\nEnter third points (x3, y3)\n");  
    scanf("\n%f%f", &x3, &y3);  
  
    a = (y2 - y1) / (x2 - x1);  
    b = (y3 - y2) / (x3 - x2);  
  
    if( a == b)  
        printf("All 3 points (%.2f,%.2f), (%.2f,%.2f) and (%.2f,%.2f)  lie on the same line\n", x1,y1,x2,y2,x3,y3);  
    else
        printf("All 3 points (%.2f,%.2f), (%.2f,%.2f) and (%.2f,%.2f) do not lie on the same line\n",x1,y1,x2,y2,x3,y3);  
}  
