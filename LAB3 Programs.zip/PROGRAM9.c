#include<stdio.h>
void main()
{
	int a;
	printf("enter a number : ");
	scanf("%d", &a);
	if (a>0)
		printf("the given number is positive");
	else if (a<0)
		printf("the given number is negative");
	else
		printf("the given number is zero");	
}
