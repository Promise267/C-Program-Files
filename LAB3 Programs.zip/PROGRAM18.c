#include<stdio.h>
void main()
{
	int opt,a,b;
	printf("enter the first integer : ");
	scanf("%d", &a);
	printf("enter the second integer : ");
	scanf("%d", &b);
START: 
	printf("---------------------------------------------------------------------------------------\n");
		printf("Enter Your Option:\n1.Sum\n2.Difference\n3.Product\n4.Quotient\n5.Remainder\n6.Exit:\n ");
		scanf("%d", &opt);
	switch(opt)
	{
		case 1:
		printf("the sum of %d and %d is = %d", a, b, a+b );
		break;
			
		case 2:
		printf("the difference of %d and %d = %d", a, b, a-b );
		break;
			
		case 3:
		printf("the product of %d and %d = %d", a, b, a*b );
		break;
			
		case 4:
		{
		if (b==0)
			printf("Quotient can't be displayed if second integer is 0.");
		else
			printf("the quotient of %d and %d = %d", a, b, a/b );
			break;
		}
			
		case 5:
		printf("the remiander of %d and %d = %d", a, b ,a%b);
		break;
			
		case 6:
		break;
			
		default:
		printf("INCORRECT OPTION, TRY AGAIN\n");
		goto START;
		break;
	}
}
