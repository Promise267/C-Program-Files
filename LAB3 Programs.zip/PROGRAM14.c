#include<stdio.h>
void main()
{
	float a, b, c, d, service1, total1, vat1, bill1, service2, total2, vat2, bill2, service3, total3, vat3, bill3, service4, total4, vat4, bill4;
	int calls;
	printf(" enter the no. of calls : ");
	scanf("%d", &calls);
	
	a = 150 * calls;
	service1 = 0.1 * a;
	total1 = a + service1 ;
	vat1 = 0.13 * total1;
	bill1 = a + service1 + vat1;
	
	b = 1.5 * calls;
	service2 = 0.1 * b;
	total2 = b + service2;
	vat2 =  0.13 * total2;
	bill2 = b + service2 + vat2;
	
	c = 1 * calls;
	service3 = 0.1 * c;
	total3 = c + service3 ;
	vat3= 0.13 * total3;
	bill3 = c + service3 + vat3;
	
	d = 0.75 * calls;
	service4 = 0.1 * d;
	total4 = d + service4 ;
	vat4 = 0.13 * total4;
	bill4 = d + service4 + vat4;
	
	if (calls<=200)
		printf(" Your number of calls is %d \n Bill amount is Rs.%.2f \n Total service charge is Rs.%.2f \n Total VAT amount is Rs.%.2f \n Total sum of bill amount including service charge and VAT is Rs.%.2f", calls, a, service1, vat1, bill1);
	else if (calls>200 && calls<=500)
		printf(" Your number of calls is %d \n Bill amount is Rs.%.2f \n Total service charge is Rs.%.2f \n Total VAT amount is Rs.%.2f \n Total sum of bill amount including service charge and VAT is Rs.%.2f", calls, b, service2, vat2, bill2);
	else if (calls>500 && calls<=1000)
		printf(" Your number of calls is %d \n Bill amount is Rs.%.2f \n Total service charge is Rs.%.2f \n Total VAT amount is Rs.%.2f \n Total sum of bill amount including service charge and VAT is Rs.%.2f", calls, c, service3, vat3, bill3);
	else
		printf(" Your number of calls is %d \n Bill amount is Rs.%.2f \n Total service charge is Rs.%.2f \n Total VAT amount is Rs.%.2f \n Total sum of bill amount including service charge and VAT is Rs.%.2f", calls, d, service4, vat4, bill4);	
}
