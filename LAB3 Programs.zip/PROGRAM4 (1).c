#include<stdio.h>
void main()
{
	int a;
	printf("enter a number to check wether it is divisble by 5 but not by 7 : ");
	scanf("%d", &a);
	if (a%5==0 && a%7==0)
		printf("%d is divisible by 5 and 7",a);
	else if (a%5==0 && a%7!=0)
		printf("%d is divisible by 5 but not by 7",a);
	else if (a%5!=0 && a%7==0)
		printf("%d is not divisible by 5 but by 7",a);	
	else
		printf("%d is not divisible by both 5 and 7",a);		
}
