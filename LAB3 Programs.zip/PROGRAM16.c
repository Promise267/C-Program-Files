#include<stdio.h>
void main()
{
	int s1,s2,s3,s4,s5,total;
	float percentage;
	
	printf("enter your marks in first subject : ");
	scanf("%d", &s1);
	printf("enter your marks in second subject : ");
	scanf("%d", &s2);
	printf("enter your marks in third subject : ");
	scanf("%d", &s3);
	printf("enter your marks in fourth subject : ");
	scanf("%d", &s4);
	printf("enter your marks in fifth subject : ");
	scanf("%d", &s5);
	
	if (s1>=40 && s2>=40 && s3>=40 && s4>=40 && s5>=40)
	{
		printf("YOU PASSED\n");
		total=(s1+s2+s3+s4+s5);
		percentage=(total/5);
		
		if (percentage>=80) 
		{
		printf("You Scored Distinction"); 
		} 
		else if (percentage>=70) 
		{
		printf("You Scored First Division");
		}
		else if (percentage>=55) 
		{
		printf("You scored Second Division");
		}
		else 
		{
		printf("You Just Passed");
		}
	}
	else
	{
		printf("YOU FAILED");
	}
}
