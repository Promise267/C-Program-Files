 #include<stdio.h>
void main ()
{
	char ch;
	printf("Enter any character : ");
	scanf("%c", &ch);
	if ((ch>0 && ch<=47)||(ch>=58 && ch<=64)||(ch>=91 && ch<=96)||(ch>=123 && ch<=127))
		printf("Character is a special symbol");
	else if (ch>=48 && ch<=57)
		printf("Character is a digit");
	else if (ch>=97 && ch<=122)
		printf("Character is a small letter");
	else
		printf("Character is a capital letter");
}
