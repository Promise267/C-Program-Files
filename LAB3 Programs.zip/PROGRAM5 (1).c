#include<stdio.h>
#include<math.h>
void main()
{
	float a,b,c,s,f,v;
	printf("enter the first side of the triangle : ");
	scanf("%f", &a);
	printf("enter the second side of the triangle : ");
	scanf("%f", &b);
	printf("enter the third side of the triangle : ");
	scanf("%f", &c);
	s=(a+b+c)/2;
	f=s*(s-a)*(s-b)*(s-c);
	v=sqrt(f);
	if ((a+b)>c && (b+c)>a && (c+a)>b)
		printf("the area of the trianlge with sides %.2f, %.2f and %.2f = %.2f" , a,b,c,v);
	else
		printf("ERROR! the sum of magnitude of any two sides must be greater than the third side\n");
}
