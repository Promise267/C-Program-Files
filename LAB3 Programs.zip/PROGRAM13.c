#include<stdio.h>
void main()
{
	int year;
	printf("enter the year : ");
	scanf("%d", &year);
	if (year%4==0)
		printf("the given year %d is leap year", year);
	else
		printf("the given year %d is not leap year", year);
}
