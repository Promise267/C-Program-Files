#include <stdio.h>
void main()
{
	int n=10,counter=1;
START:
	printf("%d\n", counter);
	counter++; 
	if(counter<=n)
	goto START;
}
