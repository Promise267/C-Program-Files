#include <stdio.h>
#include <math.h>
void main()
{
	float a,b,c,d,x,y;
	printf("enter the value of a : ");
	scanf("%f",&a);
	printf("enter the value of b : ");
	scanf("%f",&b);
	printf("enter the value of c : ");
	scanf("%f", &c);
	d=b*b-4*a*c;
	if (d>0)
	{
		printf("Roots are real and distinct");
		x=(-b + sqrt(d))/(2*a);
		y=(-b + sqrt(d))/(2*a);		
		printf("\nRootx=%f\nRoot y = %f", x,y);
	}
	else if (d==0)
	{
		printf("Roots are real and equal");
		x=b/(2*a);
		y=-b/(2*a);
		printf("\nRoot x = %f\nRoot y= %f",x,y);
	}
	else
	{
		printf("Roots are complex and conjugate");
	}
}
