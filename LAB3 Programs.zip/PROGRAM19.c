#include<stdio.h>
void main()
{
	int opt;
	printf("Enter Your Option To Display Name Of The Corresponding Day of The Week\n");
	printf("(1/2/3/4/5/6/7):");
	scanf("%d", &opt);
	switch(opt)
	{
	case 1:
		printf("The Corresponding Day is Sunday");
		break;
	case 2:
		printf("The Corresponding Day is Monday");
		break;		
	case 3:
		printf("The Corresponding Day is Tuesday");
		break;
	case 4:
		printf("The Corresponding Day is Wednesday");
		break;
	case 5:
		printf("The Corresponding Day is Thursday");
		break;
	case 6:
		printf("The Corresponding Day is Friday");
		break;
	case 7:
		printf("The Corresponding Day is Saturday");
		break;
	default:
		printf("invalid option");
		break;
	}
}
